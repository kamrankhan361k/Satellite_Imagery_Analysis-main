# Satellite Imagery Analysis
![Python](https://img.shields.io/badge/Python-3.6-green.svg)
![Stars](https://img.shields.io/github/stars/syamkakarla98/Satellite_Imagery_Analysis)
![Forks]( https://img.shields.io/github/forks/syamkakarla98/Satellite_Imagery_Analysis)
![issued](https://img.shields.io/github/issues/syamkakarla98/Satellite_Imagery_Analysis)
![License](https://img.shields.io/github/license/syamkakarla98/Satellite_Imagery_Analysis)
  
Implementation of different techniques to find insights from the satellite data using Python.
